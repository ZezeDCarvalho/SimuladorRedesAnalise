/* 
 * File:   main.c
 * Author: flavio
 *
 * Created on 26 de Abril de 2019, 16:28
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "fila.h"

#define MEDIDA 1000000.0

typedef struct little_{
	double tempo_anterior;
	double soma_areas;
	double qtd_pacotes;
}little;

/**
 * 
 * @return numero aleatorio entre (0,1]
 */
double aleatorio() {
	double u;
	u = rand() % RAND_MAX;
	u = u / RAND_MAX;
	u = 1.0 - u;

	return (u);
}

/**
 * 
 * @param l parametro da exponencial
 * @return intervalo de tempo, com media tendendo ao intervalo
 * informado pelo usuario.
 */
double chegada_pct(double l) {
	return ((-1.0 / l) * log(aleatorio()));
}

/**
 * 
 * @return tamanho do pacote que acabou de chegar,
 * seguindo a proporcao aproximada de 50% = 550 Bytes,
 * 40% = 40 Bytes e 10% = 1500 Bytes.
 */
double gera_tam_pct() {
	double a = aleatorio();
	//tamanhos convertidos
	if (a <= 0.5) {
		return ((550.0 * 8.0) / (MEDIDA));
	} else if (a <= 0.9) {
		return ((40.0 * 8.0) / (MEDIDA));
	}
	return ((1500.0 * 8.0) / (MEDIDA));
}

/**
 * 
 * @param a valor
 * @param b valor
 * @return menor dentre os valosres
 */
double minimo(double a, double b) {
	if (a <= b)
		return a;
	return b;
}

/**
 * 
 * @param l variavel de little que sera iniciada
 */
void inicia_little(little * l){
	l->qtd_pacotes = 0.0;
	l->soma_areas = 0.0;
	l->tempo_anterior = 0.0;
}

/**
 * PARÂMETROS USADOS DURANTE AS AULAS
 * Tempo de simulação: 1000 segundos.
 * Intervalo médio entre pacotes web: 0.000441 segundos. (media do tam pcts / MEDIDA)
 * Link: 10 Kbps.
 */
int main() {
    	pacote ** inicio = malloc(sizeof (pacote *));
	pacote ** fim = malloc(sizeof (pacote *));
	*inicio = NULL;
	*fim = NULL;
	
	//variavel para en
	little en;
	//variavel para ew_chegada
	little ew_chegada;
	//variavel para ew_saida
	little ew_saida;
	
	inicia_little(&en);
	inicia_little(&ew_chegada);
	inicia_little(&ew_saida);

	//iniciando a semente 
	//para a geracao dos numeros
	//pseudoaleatorios

	//int semente = time(NULL);
	int semente = 1556915527;
	printf("Semente: %d\n", semente);
	srand(semente);
	//tempo atual
	double tempo = 0.0;
	//tempo total
	double tempo_total;
	printf("Informe o tempo total de simulacao: ");
	scanf("%lF", &tempo_total);

	//intervalo medio entre chegadas (web)
	double intervalo;
	printf("Informe o intervalo médio de tempo (em segundos) entre pacotes: ");
	scanf("%lF", &intervalo);
	
	//ajustando parametro para a exponencial
	intervalo = 1.0 / intervalo;

 //     //// TRABALHO ANTIGO
 //	   //intervalo entre pacotes em segundos
 //    long double intervaloPct = (ocupacaoDesejada[j] * larguraBanda) / 441.0;

	//contador de pacotes
	//double cont_pcts = 0.0;

	//tamanho do pacote gerado
	double tam_pct;

	//tamanho do link de saida do roteador (largura de banda)
	double link;
	printf("Informe o tamanho do link: ");
	scanf("%lF", &link);

	//fila, onde fila == 0 indica
	//roteador vazio; fila == 1
	//indica 1 pacote, ja em transmissao;
	//fila > 1 indica 1 pacote em transmissao,
	//e demais em espera
	//double fila = 0.0;

	//tempo de chegada do proximo pacote
	//ao sistema
	double chegada_proximo_pct = chegada_pct(intervalo);
	//printf("Chegada do primeiro pacote: %lF\n", chegada_proximo_pct);

	//tempo de chegada do proximo pacote
	//cbr ao sistema, com intervalo
	//de 20 ms entre pacotes
	double chegada_proximo_pct_cbr = 0.02;


	//tempo de saida do pacote que esta
	//sendo atendido atualmente
	double saida_pct_atendimento;

	//variavel para o calculo da ocupacao
	//do roteador
	double ocupacao = 0.0;

        while (tempo <= tempo_total) {
		//roteador vazio. Logo, avanco
		//no tempo para a chegada do
		//proximo pacote. [web e cbr]
		if (*inicio == NULL)
			tempo = minimo(chegada_proximo_pct_cbr, chegada_proximo_pct);
		else {
                        //ha fila! 3 eventos possíveis chegada pct cbr ou web ou saída de pct
                        tempo = minimo(minimo(chegada_proximo_pct_cbr, chegada_proximo_pct), saida_pct_atendimento);
		}

		//chegada de pacote web
		if (tempo == chegada_proximo_pct) {
			//gero o tamanho do pacote
			tam_pct = gera_tam_pct();

			if (*inicio == NULL) {
				//gerando o tempo de atendimento
				saida_pct_atendimento = tempo + tam_pct / link;
				//calculo da ocupacao
				ocupacao += saida_pct_atendimento - tempo;
			}
			//pacote colocado na fila
			inserir(inicio, fim, tam_pct);

			//gerar o tempo de chegada do proximo
			chegada_proximo_pct = tempo + chegada_pct(intervalo);
			
			//calculo little -- E[N]
			en.soma_areas += en.qtd_pacotes * (tempo - en.tempo_anterior);
			en.qtd_pacotes++;
			en.tempo_anterior = tempo;
			
			//calculo little -- E[W] chegada
			ew_chegada.soma_areas += ew_chegada.qtd_pacotes * (tempo - ew_chegada.tempo_anterior);
			ew_chegada.qtd_pacotes++;
			ew_chegada.tempo_anterior = tempo;
		} else if (tempo == chegada_proximo_pct_cbr) {
			//printf("CBR chegou!\n");
			
			//chega pct cbr 1200 Bytes
                        //convertendo para megabits
			tam_pct = ((1200.0 * 8.0) / (MEDIDA));

			if (*inicio == NULL) {
				//gerando o tempo de atendimento
				saida_pct_atendimento = tempo + tam_pct / link;
				//calculo da ocupacao
				ocupacao += saida_pct_atendimento - tempo;
			}
			//pacote colocado na fila
			inserir(inicio, fim, tam_pct);

			//gerar o tempo de chegada do proximo
			chegada_proximo_pct_cbr += 0.02;
			
			//calculo little -- E[N]
			en.soma_areas += en.qtd_pacotes * (tempo - en.tempo_anterior);
			en.qtd_pacotes++;
			en.tempo_anterior = tempo;
			
			//calculo little -- E[W] chegada
			ew_chegada.soma_areas += ew_chegada.qtd_pacotes * (tempo - ew_chegada.tempo_anterior);
			ew_chegada.qtd_pacotes++;
			ew_chegada.tempo_anterior = tempo;
		} else {//saida de pacote
			//printf("Saida de pacote no tempo: %lF\n", tempo);
			remover(inicio);
			//printf("Fila: %lF\n", fila);

			if (*inicio != NULL) {
				//obtem o tamanho do pacote
				tam_pct = (*inicio)->tamanho;
				//gerando o tempo em que o pacote
				//atual saira do sistema
				saida_pct_atendimento = tempo + tam_pct / link;

				ocupacao += saida_pct_atendimento - tempo;
			}
			//calculo little -- E[N]
			en.soma_areas += en.qtd_pacotes * (tempo - en.tempo_anterior);
			en.qtd_pacotes--;
			en.tempo_anterior = tempo;
			
			//calculo little -- E[W] saida
			ew_saida.soma_areas += ew_saida.qtd_pacotes * (tempo - ew_saida.tempo_anterior);
			ew_saida.qtd_pacotes++;
			ew_saida.tempo_anterior = tempo;
		}
		//printf("==========================\n");
		//getchar();
	}
	ew_saida.soma_areas += ew_saida.qtd_pacotes * (tempo - ew_saida.tempo_anterior);
	ew_chegada.soma_areas += ew_chegada.qtd_pacotes * (tempo - ew_chegada.tempo_anterior);

	double en_final = en.soma_areas / tempo;
	double ew = ew_chegada.soma_areas - ew_saida.soma_areas;
	ew = ew / ew_chegada.qtd_pacotes;
	
	double lambda = ew_chegada.qtd_pacotes / tempo;
	
	printf("Ocupacao: %lF\n", ocupacao / tempo);
	printf("\n======Little======\n");
	printf("E[N] = %lF\n",en_final);
	printf("E[W] = %lF\n",ew);
	printf("Lambda = %lF\n",lambda);
	printf("\n==================\n");
	printf("Validacao Little: %.20lF\n", en_final - (lambda * ew));
	
	//	printf("Pacotes gerados: %lF\n", cont_pcts);
	//	printf("Media do intervalo: %lF\n", tempo/cont_pcts);	

	return (EXIT_SUCCESS);
}

