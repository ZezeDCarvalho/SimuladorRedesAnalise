#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "fila.h"

// unidade de conversao
#define MEDIDA 1000000.0

// tamanho pct cbr fixo em 1200B convertido em Mb
#define PCT_CBR_1200B ((1200.0 * 8.0) / (MEDIDA))

// tamanho pct web em Mb
#define PCT_WEB_40B ((40.0 * 8.0) / (MEDIDA))
#define PCT_WEB_550B ((550.0 * 8.0) / (MEDIDA))
#define PCT_WEB_1500B ((1500.0 * 8.0) / (MEDIDA))


// intervalo médio entre pcts cbr em segundos
#define INTERVALO_PCT_CBR 0.02

typedef struct little_ {
    double tempo_anterior;
    double soma_areas;
    double qtd_pacotes;
} little;

/**
 * @return numero aleatorio entre (0,1]
 */
double aleatorio() {
    double u;
    u = rand() % RAND_MAX;
    u = u / RAND_MAX;
    u = 1.0 - u;

    return (u);
}

/**
 * 
 * @param l parametro da exponencial
 * @return intervalo de tempo, com media tendendo ao intervalo
 * informado pelo usuario.
 */
double chegada_pct(double l) {
    return ((-1.0 / l) * log(aleatorio()));
}

/**
 * @return tamanho do pacote que acabou de chegar,
 * seguindo a proporcao aproximada:
 * 50% = 550 Bytes,
 * 40% = 40 Bytes
 * 10% = 1500 Bytes.
 */
double gera_tam_pct() {
    double a = aleatorio();
    //tamanhos convertidos para Mb
    if (a <= 0.5) {
        return PCT_WEB_550B;
    } else if (a <= 0.9) {
        return PCT_WEB_40B;
    }
    return PCT_WEB_1500B;
}

/**
 * @param a valor
 * @param b valor
 * @return menor dentre os valosres
 */
double minimo(double a, double b) {
    return (a <= b) ? a : b;
}

/**
 * @param l variavel de little que sera iniciada
 */
void inicia_little(little * l) {
    l->qtd_pacotes = 0.0;
    l->soma_areas = 0.0;
    l->tempo_anterior = 0.0;
}

// evento[] = {conexao, cbr, web}
void to_string(double *conexao){
    printf("\n======= CONTROLE ============");
    printf("\nConexões ..: %10.5lF", conexao[0]);
    printf("\nPacotes cbr: %10.5lF", conexao[1]);
    printf("\nPacotes web: %10.5lF", conexao[2]);
    printf("\n============================\n");
}

// campos[] = {en_final, ew, lambda, tempo, ocupacao}
void imprime_parametros(double *campos){
    printf("\n====== LITTLE ============\n");
    printf("E[N] = %lF\n", campos[0]);
    printf("E[W] = %lF\n", campos[1]);
    printf("Lambda = %lF\n", campos[2]);
    printf("Validação: %.20lF\n", campos[0] - (campos[2] * campos[1]));
    printf("============================\n");
    printf("Ocupação: %lF\n", campos[4] / campos[3]);
    printf("============================\n\n");
}

/**
 * PARÂMETROS USADOS DURANTE AS AULAS
 * Tempo de simulação: 1000 segundos.
 * Intervalo médio entre pacotes web: 0.000441 segundos.
 * Link: 10 Mbps.
 */
int main() {
    pacote ** inicio = malloc(sizeof (pacote *));
    pacote ** fim = malloc(sizeof (pacote *));
    pacote ** conexao_inicio = malloc(sizeof (pacote *));
    pacote ** conexao_fim = malloc(sizeof (pacote *));
    
    *inicio = *fim = *conexao_inicio = *conexao_fim = NULL;

    //variavel para en
    little en;
    //variavel para ew_chegada
    little ew_chegada;
    //variavel para ew_saida
    little ew_saida;

    inicia_little(&en);
    inicia_little(&ew_chegada);
    inicia_little(&ew_saida);

    //iniciando a semente 
    //para a geracao dos numeros
    //pseudoaleatorios
    //int semente = time(NULL);
    int semente = 1556915527;
    printf("Semente: %d\n", semente);
    srand(semente);
    
    //tempo atual
    double tempo = 0.0;
    //tempo total de simulacao
    double tempo_total = 1000.0;

    //tamanho do link de saida do roteador (LARGURA DE BANDA Mb)
    double link = 10.0;

    /*=====================================================================================+
     |   (pcts/seg = 1/intervalo_chegada) x (tamanho médio dos pcts)                       |
     |  ------------------------------------------------------------- =  (% de ocupacao)   |
     |                 (largura de banda)                                                  |
     |                                                                                     |
     |  SOLUCAO PARA AUMENTAR OCUPACAO:                                                    |
     |      1. alterar intervalo de chegada de pct e fixar a largura de banda              |
     |      2. diminuir largura de banda e fixar o intervalo de pcts                       |
     +=====================================================================================*/

    //variavel para o calculo da ocupacao
    double ocupacao_web = 0.0;
    double ocupacao_cbr = 0.0;
    double ocupacao = 0.0;

    
    // intervalo medio entre chegadas (pct WEB)
    // proporcao = 10%x1500B + 40%x40B + 50%x550B
    //            = 150 + 16 + 275 = 441B
    // intervalo em Mb = proporcao / 1000000
    double intervalo_web = 0.000441;

    //ajustando parametro para a exponencial
    intervalo_web = 1.0 / intervalo_web;

    //tamanho do pacote gerado
    double tam_pct;

    //tempo de saida do pacote atualmente atendido
    double saida_pct_atendimento;

    //tempo de chegada do proximo pacote ao sistema
    double chegada_proximo_pct_web = chegada_pct(intervalo_web);

    // PARAMETROS INFORMADOS PELO USUARIO:
    // intervalo entre conexões
    double intervalo_conexoes = 0.0;
    printf("Informe o intervalo entre conexões: ");
    scanf("%lf", &intervalo_conexoes);
    // duração de cada conexão
    double duracao_conexao = 0.0;
    printf("Informe a duração de cada conexão: ");
    scanf("%lf", &duracao_conexao);

    // ajustando parametro para a exponencial
    intervalo_conexoes = 1 / intervalo_conexoes;

    // tempo de chegada da conexao
    double chegada_proxima_conexao_cbr = chegada_pct(intervalo_conexoes);

    //tempo de chegada do proximo pacote
    //cbr ao sistema, com intervalo
    //de 20 ms entre pacotes
    //double chegada_proximo_pct_cbr = INTERVALO_PCT_CBR;
    
    // chegada de pct cbr depois da conexao da chegada de conexao
    double chegada_proximo_pct_cbr = chegada_proxima_conexao_cbr + INTERVALO_PCT_CBR;
    
    // tempo final da conexao
    double fim_conexao_cbr = chegada_proximo_pct_cbr + duracao_conexao;

    // double qtd conexoes
    double conexoes = 0.0;
    
    // controle
    double repeticao = 0.0;
    double pct_cbr = 0.0;
    double pct_web = 0.0;
    
    while (tempo <= tempo_total) {
        // roteador vazio
        // avanco para gerar chegada do proximo pct [WEB ou CBR], ou da proxima conexao
        if (*inicio == NULL)
            tempo = minimo(minimo(chegada_proximo_pct_cbr, chegada_proximo_pct_web), chegada_proxima_conexao_cbr);
        else {
            // TEM FILA!
            //4 eventos possíveis chegada pcts cbr ou web, saída de pct e nova conexao cbr
            tempo = minimo(minimo(chegada_proximo_pct_cbr, chegada_proximo_pct_web), minimo(saida_pct_atendimento, chegada_proxima_conexao_cbr));
        }

        //chegada de pacote web
        if (tempo == chegada_proximo_pct_web) {
            pct_web++;
            
            //gero o tamanho do pacote
            tam_pct = gera_tam_pct();

            // fila vazia
            if (*inicio == NULL) {
                //gerando o tempo de atendimento
                saida_pct_atendimento = tempo + tam_pct / link;
                //calculo da ocupacao
                ocupacao_web += saida_pct_atendimento - tempo;
            }
            //pacote colocado na fila
            inserir(inicio, fim, tam_pct, -1);

            //gerar o tempo de chegada do proximo
            chegada_proximo_pct_web = tempo + chegada_pct(intervalo_web);

            //calculo little -- E[N]
            en.soma_areas += en.qtd_pacotes * (tempo - en.tempo_anterior);
            en.qtd_pacotes++;
            en.tempo_anterior = tempo;

            //calculo little -- E[W] chegada
            ew_chegada.soma_areas += ew_chegada.qtd_pacotes * (tempo - ew_chegada.tempo_anterior);
            ew_chegada.qtd_pacotes++;
            ew_chegada.tempo_anterior = tempo;
        } else if (tempo == chegada_proximo_pct_cbr) {// chegada de pct cbr
            pct_cbr++;
            
            double tempo_pct_cbr = 0.0;
            
            if (*inicio == NULL) {
                // pcts da conexao 
                tempo_pct_cbr = remover(conexao_inicio);
                
                if ((*conexao_fim)->fim_conexao <= fim_conexao_cbr){
                    inserir(conexao_inicio, conexao_fim, tempo, fim_conexao_cbr);
                }
                
                //gerando o tempo de atendimento
                saida_pct_atendimento = tempo + PCT_CBR_1200B / link;
                //calculo da ocupacao
                ocupacao_cbr += saida_pct_atendimento - tempo;
            }else{
                
                if(conexoes == 1){
                
                }
            
            
            
            }
            
            // colocado na fila do roteador para ser atendido    
            inserir(conexao_inicio, conexao_fim, tempo, fim_conexao_cbr);

            //gerar o tempo de chegada do proximo pct (tempo + intervalo < fim_conexao)
            if ((tempo + INTERVALO_PCT_CBR) <= fim_conexao_cbr) {
                chegada_proximo_pct_cbr += INTERVALO_PCT_CBR;
            }

            en.soma_areas += en.qtd_pacotes * (tempo - en.tempo_anterior);
            en.qtd_pacotes++;
            en.tempo_anterior = tempo;

            //calculo little -- E[W] chegada
            ew_chegada.soma_areas += ew_chegada.qtd_pacotes * (tempo - ew_chegada.tempo_anterior);
            ew_chegada.qtd_pacotes++;
            ew_chegada.tempo_anterior = tempo;
        
        } else if (tempo == saida_pct_atendimento) {//saida de pacote
            // remover o pct da fila
            remover(inicio);

            // se tem mais pcts na fila
            if (*inicio != NULL) {
                // obtem o tamanho do pacote
                tam_pct = ((*inicio)->tamanho_tempo == PCT_WEB_1500B 
                            || (*inicio)->tamanho_tempo == PCT_WEB_550B 
                            || (*inicio)->tamanho_tempo == PCT_WEB_40B) 
                        ? (*inicio)->tamanho_tempo : PCT_CBR_1200B;

                // tempo em que o pct atual saira do sistema
                saida_pct_atendimento = tempo + tam_pct / link;

                ocupacao_web += saida_pct_atendimento - tempo;
            }
            //calculo little -- E[N]
            en.soma_areas += en.qtd_pacotes * (tempo - en.tempo_anterior);
            en.qtd_pacotes--;
            en.tempo_anterior = tempo;

            //calculo little -- E[W] saida
            ew_saida.soma_areas += ew_saida.qtd_pacotes * (tempo - ew_saida.tempo_anterior);
            ew_saida.qtd_pacotes++;
            ew_saida.tempo_anterior = tempo;
        } else { // nova conexao
            conexoes++;
            // primeiro pct que será atendido após a conexao
            chegada_proximo_pct_cbr = tempo;

            // fim da conexao
            fim_conexao_cbr = chegada_proxima_conexao_cbr + duracao_conexao;

            // gerando o tempo da proxima conexao
            chegada_proxima_conexao_cbr = tempo + chegada_pct(intervalo_conexoes);
        }
    
        repeticao++;
        if (repeticao > 10000000){
            printf("\nINFINITYYYYY\n");
            break;
        }
    }
    
    ew_saida.soma_areas += ew_saida.qtd_pacotes * (tempo - ew_saida.tempo_anterior);
    ew_chegada.soma_areas += ew_chegada.qtd_pacotes * (tempo - ew_chegada.tempo_anterior);

    double en_final = en.soma_areas / tempo;
    double ew = ew_chegada.soma_areas - ew_saida.soma_areas;
            ew = ew / ew_chegada.qtd_pacotes;

    double lambda = ew_chegada.qtd_pacotes / tempo;

    double parametros_little [] = {en_final, ew, lambda, tempo, ocupacao_web};
    double parametros_pcts[] = {conexoes, pct_cbr, pct_web};
    
    imprime_parametros(parametros_little);
    to_string(parametros_pcts);
    
    return (EXIT_SUCCESS);
}




