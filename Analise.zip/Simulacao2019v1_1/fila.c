#include<stdlib.h>
#include<stdio.h>
#include"fila.h"

pacote * aloca_pct(){
	return (malloc(sizeof(pacote)));
}

/**
 * 
 * @param inicio aponta o primeiro da fila
 * @param fim aponta o ultimo da fila
 * @param tamanho do pacote a ser inserido
 * @param tempo_conexao tempo final da conexao
 * @return 1 caso insira, 0 caso erro
 */
int inserir(pacote ** inicio, pacote ** fim, double tamanho_tempo, double fim_conexao){
	//fila vazia
	if(*inicio == NULL){
		*inicio = aloca_pct();
		if(*inicio == NULL){
			return 0;
		}
		*fim = *inicio;
		(*inicio)->tamanho_tempo = tamanho_tempo;
		(*inicio)->prox = NULL;
		return 1;
	}else{
		pacote * tmp = aloca_pct();
		if(tmp == NULL){
			return 0;
		}
		tmp->tamanho_tempo = tamanho_tempo;
		tmp->prox = NULL;
		(*fim)->prox = tmp;
		(*fim) = tmp;
		return 1;
	}
}


/**
 * 
 * @param inicio da fila
 * @return 0 caso fila vazia, tamanho do pct caso contrario
 */
double remover(pacote ** inicio){
	if(*inicio == NULL){
		return 0;
	}else{
		pacote * tmp = *inicio;
		double tamanho_tempo = (*inicio)->tamanho_tempo;
		(*inicio) = (*inicio)->prox;
		free(tmp);
		return tamanho_tempo;
	}
}

